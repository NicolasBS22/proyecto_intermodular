La Juanadería
Nicolás Bercial Seminario (líder)
lya Mikhalev 
Kiril Kuleshov 